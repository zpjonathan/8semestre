import time

def es_primo(n):
    if n < 2:
        return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True

def calcular_primos(rango):
    inicio, fin = rango
    print(f"Calculando primos en el rango {inicio}-{fin}")
    primos = [n for n in range(inicio, fin) if es_primo(n)]
    print(f"{len(primos)} primos encontrados en el rango {inicio}-{fin}.")

if __name__ == "__main__":
    rangos = [(2, 400000), (400001, 800000), (800001, 1200000)]
    start_time = time.time()
    for rango in rangos:
        calcular_primos(rango)
    end_time = time.time()
    print(f"Tiempo total: {end_time - start_time:.2f} segundos")



