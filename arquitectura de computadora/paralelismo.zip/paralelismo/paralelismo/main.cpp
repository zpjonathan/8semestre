#include <iostream>
#include <chrono>
#include <vector>
#include <thread>

bool es_primo(int n) {
    if (n < 2) return false;
    for (int i = 2; i * i <= n; ++i)
        if (n % i == 0) return false;
    return true;
}

void calcular_primos(int inicio, int fin) {
    int total = 0;
    for (int i = inicio; i <= fin; ++i)
        if (es_primo(i)) total++;
    std::cout << "Primos en [" << inicio << ", " << fin << "]: " << total << "\n";
}

int main() {


    std::cout << "Prueba en paralelo\n";

    auto inicio = std::chrono::high_resolution_clock::now();

    std::thread t1(calcular_primos, 2, 400000);
    std::thread t2(calcular_primos, 400001, 800000);
    std::thread t3(calcular_primos, 800001, 1200000);

    t1.join();
    t2.join();
    t3.join();

    auto fin = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> duracion = fin - inicio;
    std::cout << "Tiempo total (threading): " << duracion.count() << " segundos\n";
    return 0;
}
