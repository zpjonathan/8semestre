import time
import threading

def es_primo(n):
    if n < 2:
        return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True

def calcular_primos(rango):
    inicio, fin = rango
    print(f"[{threading.current_thread().name}] Calculando primos en el rango {inicio}-{fin}")
    primos = [n for n in range(inicio, fin) if es_primo(n)]
    print(f"[{threading.current_thread().name}] {len(primos)} primos encontrados en el rango {inicio}-{fin}.")

if __name__ == "__main__":

    rangos = [(2, 400000), (400001, 800000), (800001, 1200000)]

    hilos = []

    start_time = time.time()

    for i, rango in enumerate(rangos):
        hilo = threading.Thread(target=calcular_primos, args=(rango,), name=f"Hilo-{i+1}")
        hilos.append(hilo)
        hilo.start()
    
    for hilo in hilos:
        hilo.join()

    end_time = time.time()
    print(f"Tiempo total: {end_time - start_time:.2f} segundos")
