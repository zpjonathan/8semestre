import time
import multiprocessing

def es_primo(n):
    if n < 2:
        return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True

def calcular_primos(rango):

    inicio, fin = rango
    print(f"Calculando primos en el rango {inicio}-{fin}")
    primos = [n for n in range(inicio, fin) if es_primo(n)]
    print(f"Primos en el rango {inicio}-{fin}: {len(primos)} encontrados.")

if __name__ == "__main__":
    rangos = [(2, 400000), (400001, 800000), (800001, 1200000)]
    procesos = []
    start_time = time.time()
    for rango in rangos:
        p = multiprocessing.Process(target=calcular_primos, args=(rango,))
        procesos.append(p)
        p.start()
    for p in procesos:
        p.join()

    end_time = time.time()
    print(f"Tiempo total: {end_time - start_time:.2f} segundos")